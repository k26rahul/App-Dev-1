from .root_bp import root_bp
from .student_bp import student_bp
